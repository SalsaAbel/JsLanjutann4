import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './style.css';

function LoginPage() {
  const [role, setRole] = useState('user');
  const navigate = useNavigate();

  const handleLogin = () => {
    localStorage.setItem('role', role);
    if (role === 'admin') {
      navigate('/admin/dashboard');
    } else {
      navigate('/');
    }
  };

  return (
    <div className="container">
      <h2>Login Page</h2>
      <label>Pilih Peran:</label>
      <select value={role} onChange={(e) => setRole(e.target.value)}>
        <option value="user">User</option>
        <option value="admin">Admin</option>
      </select>
      <button onClick={handleLogin}>Login</button>
    </div>
  );
}

export default LoginPage;
