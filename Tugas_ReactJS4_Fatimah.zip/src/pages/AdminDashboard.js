import React from 'react';
import './style.css';

function AdminDashboard() {
  return (
    <div className="container">
      <h1>Dashboard Admin</h1>
      <p>Hanya admin yang bisa mengakses halaman ini.</p>
    </div>
  );
}

export default AdminDashboard;
