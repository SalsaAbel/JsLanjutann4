import React from 'react';
import './style.css';

function ProfilePage() {
  const role = localStorage.getItem('role');
  return (
    <div className="container">
      <h1>Halaman Profil</h1>
      <p>Anda login sebagai: <strong>{role}</strong></p>
    </div>
  );
}

export default ProfilePage;
