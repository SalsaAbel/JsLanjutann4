import React from 'react';
import { Link } from 'react-router-dom';
import './style.css';

function HomePage() {
  return (
    <div className="container">
      <h1>Beranda Booksales</h1>
      <p>Selamat datang di aplikasi toko buku online.</p>
      <Link to="/profile">Profil</Link> | <Link to="/admin/dashboard">Dashboard Admin</Link> | <Link to="/login">Login</Link>
    </div>
  );
}

export default HomePage;
